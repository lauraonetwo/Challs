package clickergame;

public class Main {
    public static void main(String[] args) {
            String textSet = (new c("asdfff")).getHex();

            System.out.println(textSet);
    }
}
