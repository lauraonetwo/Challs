package clickergame;

public class a {
   String a = "2d644cd693bb";

   public a(String var1) {
      this.a = this.a + var1;
   }

   public static char[] OOOO000OOO0000O00000(char[] var0, int var1) {
      char[] var4 = new char[var1];
      int var2 = 0;

      for(int var3 = var1; var2 < var1; ++var2) {
         --var3;
         var4[var3] = var0[var2];
      }

      return var4;
   }

   public static String OOOO000OOO000OO00000(String var0) {
      char[] var4 = OOOO000OOO0000O00000(var0.toCharArray(), var0.toCharArray().length);
      int var3 = var4.length;
      var0 = "";

      for(int var2 = 0; var2 < var3; ++var2) {
         char var1 = var4[var2];
         var0 = var0 + String.valueOf(var1);
      }

      return var0;
   }
}
