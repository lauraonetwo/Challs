package clickergame;

public class b {
   String b = "aaaa";

   public b(String var1) {
      this.b = this.b + var1;
   }

   public void removeItem(String var1, String var2) {
      if (var1 != null) {
         for(int var3 = 0; var3 < 2245; ++var3) {
         }
      }

   }
}
