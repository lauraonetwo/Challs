package clickergame;

import java.math.BigInteger;
import java.security.MessageDigest;

public class c {
   a a = new a("2cf24dba5fb0a30e26e83b2ac5b");
   b b;
   String d = "";
   String input;
   a o;
   String var1;

   public c(String var1x) {
      this.b = new b(this.a.a);
      this.var1 = "e29e1b161e5c1fa7425e7304";
      this.o = new a("OOO000OO00OO000");
      this.input = var1x;
   }

   public String OOO00000000OO0O0O0O000O() {
      char[] var5 = this.b.b.toCharArray();
      int var3 = var5.length;
      String var4 = "";

      for(int var2 = 0; var2 < var3; ++var2) {
         char var1x = var5[var2];
         var4 = var4 + (Character.getNumericValue(var1x) ^ Integer.valueOf("44"));
      }

      return var4;
   }

   public String getHex() {
      try {
         MessageDigest var1x = MessageDigest.getInstance("SHA-256");
         StringBuilder var2 = new StringBuilder();
         byte[] var4 = var1x.digest(var2.append(clickergame.a.OOOO000OOO000OO00000(this.b.b)).append(this.input).toString().getBytes("UTF-8"));
         BigInteger var6 = new BigInteger(1, var4);
         String var5 = String.format("%032X", var6);
         this.var1 = var5;
         var5 = var5.substring(0, Math.min(var5.length(), 32));
         this.var1 = var5;
         return var5;
      } catch (Exception var3) {
         return null;
      }
   }
}
